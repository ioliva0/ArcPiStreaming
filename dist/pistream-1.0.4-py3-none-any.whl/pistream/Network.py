server_socket = None
server_address = ("172.17.17.120", 9999)
camera = None

client_socket = None
client_address = None

frame_requested = False
stream_requested = False
