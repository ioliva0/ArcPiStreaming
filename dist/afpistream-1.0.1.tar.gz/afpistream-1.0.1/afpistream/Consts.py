PACK_SIZE = 4096
BUFFER_PACKETS = 10
JPEG_QUALITY = 50 #1-100, recommended 50-80, higher quality = slower streaming
RESOLUTION = (1920, 1080)
EXPOSURE = 130000